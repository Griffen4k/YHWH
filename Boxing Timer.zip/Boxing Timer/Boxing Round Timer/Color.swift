//
//  Color.swift
//  Boxing Round Timer
//
//  Created by YHWH on 6/15/17.
//  Copyright © 2017 YHWH. All rights reserved.
//

import Foundation
import UIKit

extension UIColor {
    
    static var orangeTimerColor: UIColor {
        return UIColor(red: 252 / CGFloat(255), green: 126 / CGFloat(255), blue: 15 / CGFloat(255), alpha: 1.0)
    }
    
    static var brownTimerColor: UIColor {
        return UIColor(red: 252 / CGFloat(255), green: 255 / CGFloat(255), blue: 0 / CGFloat(255), alpha: 1.0)
    }
    
    static var tanTimerColor: UIColor {
        return UIColor(red: 240 / CGFloat(255), green: 167 / CGFloat(255), blue: 104 / CGFloat(255), alpha: 1.0)
    }
    
    static var blueTimerColor: UIColor {
        return UIColor(red: 197 / CGFloat(255), green: 4 / CGFloat(255), blue: 27 / CGFloat(255), alpha: 1.0)
    }
    
    static var lightBlueTimerColor: UIColor {
        return UIColor(red: 197 / CGFloat(255), green: 4 / CGFloat(255), blue: 27 / CGFloat(255), alpha: 1.0)
    }
}
