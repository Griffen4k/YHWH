//
//  ViewController.swift
//  Boxing Round Timer
//
//  Created by YHWH on 6/5/17.
//  Copyright © 2017 YHWH. All rights reserved.
//

import UIKit
import AVFoundation;
import AudioToolbox

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var switchVibrate: UISwitch!
    
    @IBOutlet weak var testLabel: UILabel!
    @IBOutlet weak var testPickerView: UIPickerView!
    
    
    
    
    var timer:Timer = Timer()
    var audioPlayer : AVAudioPlayer!
    var restSeconds:intmax_t = 0
    var roundTime:intmax_t = 30
    var roundsVal:intmax_t = 1
    var seconds : intmax_t = 180
    var minutes : intmax_t = 10
    var roundsPicker : intmax_t = 10
    var rest:String = ""
    var roundtime:String = ""
    var rounds:String = ""
    var warningvar = 0
    
    var isTimerRunning = false
    var resumeTapped = false
    
    var dataList = [
        [ "0sec","15sec","30sec","60sec","90sec","120sec","150sec","180sec"],
        ["30 sec","1min","2min","3min","4min","5min","6min","7min","8min","9min","10min"],
    ["Round 1", "Round 2", "Round 3", "Round 4", "Round 5", "Round 6", "Round 7", "Round 8", "Round 9", "Round 10"]
    ]
    
    var PickerView = UITextView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        testPickerView.delegate = self
        testPickerView.dataSource = self
        testLabel.isHidden = true
        
        pauseButton.layer.cornerRadius = pauseButton.bounds.height / 2
        pauseButton.layer.masksToBounds = true
        pauseButton.layer.borderWidth = 2.0
        pauseButton.layer.borderColor = UIColor.blueTimerColor.cgColor
        
        startButton.layer.cornerRadius = startButton.bounds.height / 2
        startButton.layer.masksToBounds = true
        startButton.layer.borderWidth = 2.0
        startButton.layer.borderColor = UIColor.lightBlueTimerColor.cgColor
        
        resetButton.layer.cornerRadius = resetButton.bounds.height / 2
        resetButton.layer.masksToBounds = true
        resetButton.layer.borderWidth = 2.0
        resetButton.layer.borderColor = UIColor.blueTimerColor.cgColor
        
        do
        {
            let audioPath = Bundle.main.path(forResource: "musarii", ofType: ".mp3")
            try audioPlayer = AVAudioPlayer(contentsOf: URL(fileURLWithPath: audioPath!))
            
        }
        catch
        {
            //ERROR
        }
        
        }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
        func playSound() {
            guard Bundle.main.url(forResource: "musarii", withExtension: "mp3") != nil else {
                print("error")
                return
            }
        }
        
        func vibratePhone() {
            seconds += 1
            switch seconds {
            case 1, 2:
                AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
            default:
                timer.invalidate()
            }
            AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
        }
        
        
}

    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return dataList.count
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 3
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return dataList[component][row] as? String
    }
    
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return dataList[component].count
    }
    
    
    func pickerView(_ pickerView: UIPickerView,didSelectRow row: Int, inComponent component: Int)
    {
     
        print(component)
        print(row)
        
        
        
        
        switch (component){
            
        case 0:
            rest = dataList[component][row]
            /* restLabel.text = rest*/
            print(rest)
            
            
            switch (row) {
            case 0 :
                restSeconds = 0
            case 1 :
                restSeconds = 15
            case 2 :
                restSeconds = 30
            case 3 :
                restSeconds = 60
            case 4 :
                restSeconds = 90
            case 5 :
                restSeconds = 120
            case 6 :
                restSeconds = 150
            case 7 :
                restSeconds = 180
                
            default:break }
            print("Restval = ",(restSeconds))
            
            
        case 1:
            
            roundtime = dataList[component][row]
            /* roundtimela.text = roundtime*/
            print(roundtime)
            
            switch (row) {
            case 0 :
                roundTime = 30
            case 1 :
                roundTime = 60
            case 2 :
                roundTime = 120
            case 3 :
                roundTime = 180
            case 4 :
                roundTime = 240
            case 5 :
                roundTime = 300
            case 6 :
                roundTime = 360
            case 7 :
                roundTime = 420
            case 8 :
                roundTime = 480
            case 9 :
                roundTime = 540
            case 10 :
                roundTime = 600
            case 11 :
                roundTime = 660
                
                
            default:break }
            print("RoundtimeVal = ",(roundTime))
            
            
        case 2:
            rounds = dataList[component][row]
            /*roundsLabel.text = rounds */
            print(rounds);
            
            switch (row) {
            case 0 :
                roundsVal = 1
            case 1 :
                roundsVal = 2
            case 2 :
                roundsVal = 3
            case 3 :
                roundsVal = 4
            case 4 :
                roundsVal = 5
            case 5 :
                roundsVal = 6
            case 6 :
                roundsVal = 7
            case 7 :
                roundsVal = 8
            case 8 :
                roundsVal = 9
            case 9 :
                roundsVal = 10
            case 10 :
                roundsVal = 11
            case 11 :
                roundsVal = 12
            case 12 :
                roundsVal = 13
            case 13 :
                roundsVal = 14
            case 14 :
                roundsVal = 15
                
                
            default:break }
            print("Roundsval = ",(roundsVal))
            
            
        default:break
        }
        
    }

        
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView
    {
        let pickerLabel = UILabel()
        pickerLabel.textAlignment = NSTextAlignment.left
        pickerLabel.text = String(describing: dataList[component][row])
        pickerLabel.backgroundColor = UIColor.red
        
        return pickerLabel
    }
    
    
    func runTimer() {
        if timer.isValid{
        
        }else{
            timer = Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: (#selector(ViewController.updateTimer)), userInfo: nil, repeats: true)

        }
        
        isTimerRunning = true
            
    }
    
    func timeString(time:TimeInterval) -> String {
        
        let minutes = Int(time) / 60 % 60
        let second = Int(time) % 60
        
        return String(format:"%02i:%02i", minutes, second)
        
    }
    
    func endTimer() {
        timer.invalidate()
    }
    
    private func updateTimerLabel() {
        testLabel.text = timeString(time: TimeInterval(minutes))
        testLabel.text = timeString(time: TimeInterval(seconds))
    }
    
   
    
    func updateTimer() {
        
        if minutes > 0 {
            minutes -= 1
            testLabel.text = timeString(time: TimeInterval(minutes))
            roundNumberLabel.isHidden = true
            roundTimeLabel.isHidden = false
        } else if seconds > 0 {
            seconds -= 1
            testLabel.text = timeString(time: TimeInterval(seconds))
            
            roundTimeLabel.isHidden = true
            restLabel.isHidden = false
        } else {
            if roundsPicker > 1 {
                roundsPicker -= 1
                testLabel.text = timeString(time: TimeInterval(roundsPicker))
                restLabel.isHidden = true
                roundNumberLabel.isHidden = false
                
                minutes = roundTime
                
                seconds = restSeconds + 1
                 self.vibreazaBlea()
                
            } else {
                 self.vibreazaBlea()
                timer.invalidate()
                startButton.isSelected = false
                testLabel.isHidden = true
                testPickerView.isHidden = false
                restLabel.isHidden = false
                roundTimeLabel.isHidden = false
                roundNumberLabel.isHidden = false
                
                startButton.setTitleColor(UIColor.blueTimerColor, for: [])
                startButton.layer.borderColor = UIColor.blueTimerColor.cgColor
                pauseButton.setTitleColor(UIColor.lightBlueTimerColor, for: [])
                pauseButton.layer.borderColor = UIColor.lightBlueTimerColor.cgColor
                resetButton.setTitleColor(UIColor.lightBlueTimerColor, for: [])
                resetButton.layer.borderColor = UIColor.lightBlueTimerColor.cgColor
                
            }
        }
        
        if (minutes == 10 && warningvar == 10)
        {
            audioPlayer.play()
            self.vibreazaBlea()
        } else {
            if (minutes == 30 && warningvar == 30) {
                audioPlayer.play()
                self.vibreazaBlea()
            }
        }
}
    
    func vibreazaBlea() {
        if switchVibrate.isOn {
            AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
        }
    }
    
    @IBAction func startCountDown(_ sender: UIButton) {
        if sender.isSelected {
            sender.isSelected = false
            timer.invalidate()
        }else{
            sender.isSelected = true
            
            if testPickerView.isHidden {
                
            }else{
                minutes = roundTime
                seconds = restSeconds + 1
                roundsPicker = roundsVal
                testLabel.text = timeString(time: TimeInterval(minutes))
                
                
                roundTimeLabel.isHidden = false
                restLabel.isHidden = true
                roundNumberLabel.isHidden = true
                testPickerView.isHidden = true
                testLabel.isHidden = false
                
                startButton.setTitleColor(UIColor.brownTimerColor, for: [])
                startButton.layer.borderColor = UIColor.orangeTimerColor.cgColor
                pauseButton.setTitleColor(UIColor.brownTimerColor, for: [])
                pauseButton.layer.borderColor = UIColor.orangeTimerColor.cgColor
                resetButton.setTitleColor(UIColor.brownTimerColor, for: [])
                resetButton.layer.borderColor = UIColor.orangeTimerColor.cgColor

            }
            runTimer()
        }
 
        
    }
    

    @IBAction func pauseButton(_ sender: UIButton) {
        
        timer.invalidate()
        
    }
    
    @IBAction func resetButton(_ sender: UIButton) {
      timer.invalidate()
        startButton.isSelected = false
        testLabel.isHidden = true
        testPickerView.isHidden = false
        restLabel.isHidden = false
        roundTimeLabel.isHidden = false
        roundNumberLabel.isHidden = false
        audioPlayer.stop()
        
        startButton.setTitleColor(UIColor.blueTimerColor, for: [])
        startButton.layer.borderColor = UIColor.blueTimerColor.cgColor
        pauseButton.setTitleColor(UIColor.lightBlueTimerColor, for: [])
        pauseButton.layer.borderColor = UIColor.lightBlueTimerColor.cgColor
        resetButton.setTitleColor(UIColor.lightBlueTimerColor, for: [])
        resetButton.layer.borderColor = UIColor.lightBlueTimerColor.cgColor
    }
   
    @IBOutlet weak var warningSecondsOutlet: UISegmentedControl!
    @IBAction func warningSeconds(_ sender: UISegmentedControl) {
        
        if(warningSecondsOutlet.selectedSegmentIndex == 0)
        {
            warningvar = 0
        }
        else
            if(warningSecondsOutlet.selectedSegmentIndex == 1)
            {
                warningvar = 10
            }
            else if(warningSecondsOutlet.selectedSegmentIndex == 2)
            {
                warningvar = 30
        }
            }
        
    @IBOutlet weak var restLabel: UITextField!
    @IBOutlet weak var roundTimeLabel: UITextField!
    @IBOutlet weak var roundNumberLabel: UITextField!
    @IBOutlet weak var pauseButton: UIButton!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!

    
    
}



